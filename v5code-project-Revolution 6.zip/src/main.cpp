// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// m1                   motor         1               
// m2                   motor         2               
// m3                   motor         3               
// m4                   motor         4               
// roller               motor         6               
// shoot1               motor         7               
// shoot2               motor         8               
// intake               motor         9               
// pusher               digital_out   A               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;
int choose = 0;

void drive(int deg, vex::directionType dir){
  m1.spinFor(dir, deg, degrees, false);
  m2.spinFor(dir, deg, degrees, false);
  m3.spinFor(dir, deg, degrees, false);
  m4.spinFor(dir, deg, degrees);
}

void increment(){
  choose++;
  if (choose == 2){
    choose--;
  }
}

void decrease(){
  choose--;
  if (choose == -1){
    choose++;
  }
}


void autondisplay(){
  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(0, 0);
  if (choose == 0){ 
      Controller1.Screen.print("Competition");
    }
    else if (choose == 1){
      Controller1.Screen.print("Skills");  
    }
}

void pre_auton(void) {
  autondisplay();
  vexcodeInit();
  shoot1.setStopping(brake);
  shoot2.setStopping(brake);
  intake.setStopping(brake);
  m1.setStopping(brake);
  m2.setStopping(brake);
  m3.setStopping(brake);
  m4.setStopping(brake);
  intake.setVelocity(100, percent);
  shoot1.setVelocity(100, percent);
  shoot2.setVelocity(100, percent);
}


void autonomous(void) {
  m1.setVelocity(75, percent);
  m2.setVelocity(75, percent);
  m3.setVelocity(75, percent);
  m4.setVelocity(75, percent);
  if (choose == 0){  
    //Competition Autonomous
    drive(360, forward);
    wait(30, msec);
    drive(360, reverse);
    wait(30, msec);
    Controller1.Screen.clearLine();
    Controller1.Screen.print("Done!");
  }


  if (choose == 1){
    //Skills Autonomous
  }
}


void usercontrol(void) {
  
  
  
  while (1) {
    m1.setVelocity(Controller1.Axis3.position(percent) + Controller1.Axis4.position(percent), percent);
    m2.setVelocity(Controller1.Axis3.position(percent) + Controller1.Axis4.position(percent), percent);
    m3.setVelocity(Controller1.Axis3.position(percent) - Controller1.Axis4.position(percent), percent);
    m4.setVelocity(Controller1.Axis3.position(percent) - Controller1.Axis4.position(percent), percent);
    //sets motor velocities to the sum or difference of Axis 3 or 4 on the controller
  
    
    
    
    
    m1.spin(forward);
    m2.spin(forward);
    m3.spin(forward);
    m4.spin(forward);
    

    
    if(Controller1.ButtonA.pressing()){
      shoot1.setVelocity(75, percent);
      shoot2.setVelocity(75, percent);
    }

    else{
      shoot1.setVelocity(100, percent);
      shoot2.setVelocity(100, percent);
    }
    

    if(Controller1.ButtonR1.pressing()){
      shoot1.spin(forward);
      shoot2.spin(forward);
    }
    else{
      shoot1.stop();
      shoot2.stop();
    }

    if(Controller1.ButtonR2.pressing()){
      pusher.set(true);
    }

    else{
      pusher.set(false);
    }

    if(Controller1.ButtonL1.pressing()){
      intake.spin(forward);
    
    
    }
    else if(Controller1.ButtonL2.pressing()){
      intake.spin(forward);
    }
    else{
      intake.stop();
    }


    if (Controller1.ButtonUp.pressing()){
      increment();
      autondisplay();

      wait(300, msec);
    }
    if (Controller1.ButtonDown.pressing()){
      decrease();
      autondisplay();

      wait(300, msec);
    }

    

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}


int main() {
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
