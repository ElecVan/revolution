using namespace vex;

extern brain Brain;

// VEXcode devices
extern controller Controller1;
extern motor m1;
extern motor m2;
extern motor m3;
extern motor m4;
extern motor roller;
extern motor shoot1;
extern motor shoot2;
extern motor intake;
extern digital_out pusher;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );